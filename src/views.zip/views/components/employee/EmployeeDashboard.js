import React from "react";

const EmployeeDashboard = ()=>{
    return(
        <>
          <main>

{/* <!-- Hero Area Start--> */}
<div class="slider-area ">
    <div class="single-slider section-overly slider-height2 d-flex align-items-center" style={{ backgroundImage: `url(assets/img/hero/about.jpg)` }}>
        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <div class="hero-cap text-center">
                        <h2>Employee Dashboard</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</main>
        </>
    )
}

export default EmployeeDashboard