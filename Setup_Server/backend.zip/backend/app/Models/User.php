<?php

namespace App\Models; 

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory; 
use Illuminate\Foundation\Auth\User as Authenticatable; 
use Illuminate\Notifications\Notifiable;
use Tymon\JWTAuth\Contracts\JWTSubject;
use App\Models\JobPost;
use App\Models\Employee;
use App\Models\Employer;

class User extends Authenticatable implements JWTSubject
{
    use HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [ 
        'name',
        'email',
        'password',
        'google_id',
        'imageurl'
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
    ];

    public function getJWTIdentifier() 
    {
        return $this->getKey(); 
    }
    /**
     * Return a key value array, containing any custom claims to be added to the JWT.
     *
     * @return array
     */
    public function getJWTCustomClaims() 
    {
        return [];
    }   
    
    public function jobPosts() 
    {
        return $this->belongsToMany(JobPost::class,'job_post_user','employee_id','job_post_id');
    }

    public function favouriteJob() 
    {
        return $this->belongsToMany(JobPost::class,'fav_job','user_id','job_id');
    }

    public function employee()
    {
        return $this->hasOne(Employee::class,'employee_id','id'); 
    }

    public function employer()
    {
        return $this->hasOne(Employer::class,'employer_id','id'); 
    }
}
